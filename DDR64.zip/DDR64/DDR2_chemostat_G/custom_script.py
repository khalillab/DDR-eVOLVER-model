import eVOLVER_module
import numpy as np
import os.path


# This code will operate eVOLVER as a pulsatile chemostat, with user-specified growth rates, bolus size, dilution start time, and starting OD.
# The code waits for the specified time, permits the culture to grow up to the specified starting OD, then initiates repeated dilutions according to specified dilution rate.
# Last Updated: Chris Mancuso 08/13/17

def test (OD_data, temp_data, vials, elapsed_time, exp_name):

    ##### Controls stir rate, increase as needed if fan not up to speed, 8, 10, 12, 14 are recommended values to try #####
    STIR_MESSAGE = "11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,"
    eVOLVER_module.stir_rate(STIR_MESSAGE)


    ##### Fixed parameters, do not change between experiments #####
    control = np.power(2,range(0,32)) #vial addresses
    flow_rate = np.array([0.925,0.9,0.925,0.975,0.975,0.9,0.9,0.95,0.95,0.9,0.875,0.975,0.95,0.95,0.9,0.925]) #ml/sec, from pump calibration
    volume =  23 #mL, from straw length
    period_config = np.array([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]) #initialize to 1000 seconds
    save_path = os.path.dirname(os.path.realpath(__file__)) #save path

    #####

    ##### USER-DEFINABLE PARAMETERS #####
    bolus = 500 #uL, 0.2-10mL is possible range, 0.5 is recommended
    start_time = 5 #hours, set 0 to start immediately
    start_OD = 0 # ~OD600, set to 0 to start at any OD

    rate_config1 = np.array([19.2,19.2,19.2,19.2,4.8,4.8,4.8,4.8,1.2,1.2,1.2,1.2,0.2,0.2,0.2,0.2]) #hr^-1, dilution rate ~ growth rate
    time1 = np.array([0.25,0.25,0.25,0.25,0.25,0.25,0.25,0.25,0.25,0.25,0.25,0.25,24,24,24,24]) #hr, length of time to run phase 1
    
    rate_config2 = np.array([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]) #hr^-1, dilution rate
    time2 = np.array([23.75,23.75,23.75,23.75,5.75,5.75,5.75,5.75,1.25,1.25,1.25,1.25,0,0,0,0]) #hr, length of time to run phase 2

    ##### EDIT ABOVE VALUES ONLY #####

    #####

    ##### Chemostat Control Code Below #####

    for x in vials: #main loop

        #initialize OD and find path
        OD_path =  "%s/%s/OD/vial%d_OD.txt" % (save_path,exp_name,x)
        data = np.genfromtxt(OD_path, delimiter=',')
        average_OD = 0

        if len(data) > 10: #waits for ten OD measurements (couple minutes)
            for n in range(1,6):
                average_OD = average_OD + (data[len(data)-n][1]/5)  #calculates average OD over a small window
            # set chemostat config path and pull values from
            chemoconfig_path =  "%s/%s/chemo_config/vial%d_chemoconfig.txt" % (save_path,exp_name,x)
            chemo_config = np.genfromtxt(chemoconfig_path, delimiter=',')
            last_chemoset = chemo_config[len(chemo_config)-1][0] #should be initial value
            last_chemophase = chemo_config[len(chemo_config)-1][1] #should be zero initially, changes each time a new command is written to file 

            #once start time has passed and culture hits start OD, if no command has been written, write new chemostat command to file
            if (((elapsed_time > start_time) & (average_OD > start_OD)) & (last_chemophase == 0)): 
                

                #calculate the period (i.e. frequency of dilution events) based on user specified growth rate and bolus size
                if rate_config1[x] > 0:
                    period_config[x] = (3600*bolus)/((rate_config1[x])*volume)
                    period_config[x] = (period_config[x])*flow_rate[x]*(25/volume) #corrects for flow rates other than 1mL/sec and volumes other than 25mL

                else: #if no dilutions needed, then just loops with no dilutions
                    period_config[x] = 0

                if  (last_chemophase == 0):
                    print 'Chemostat initiated in vial %i' % (x)
                    #writes command to chemo_config file, for storage
                    text_file = open(chemoconfig_path,"a+")
                    text_file.write("%f,1,%i\n" %  (elapsed_time,period_config[x])) #note that this sets chemophase to 1
                    text_file.close()

                #once time1 has been reached, set to phase 2
            if ((elapsed_time-last_chemoset > time1[x]) & (last_chemophase == 1)): 
                print('Switching to phase 2 in vial ',x)

                #calculate the period (i.e. frequency of dilution events) based on user specified growth rate and bolus size
                #to accomodate higher dilution rates, bolus size is doubled during phase 2 (and duration, accordingly)
                if rate_config2[x] > 0:
                    period_config[x] = (3600*bolus)/((rate_config2[x])*volume)
                    period_config[x] = (period_config[x])*flow_rate[x]*(25/volume) #corrects for flow rates other than 1mL/sec and volumes other than 25mL

                else: #if no dilutions needed, then just loops with no dilutions
                    period_config[x] = 0

                #writes command to chemo_config file, for storage
                text_file = open(chemoconfig_path,"a+")
                text_file.write("%f,2,%i\n" %  (elapsed_time,period_config[x])) #note that this sets chemophase to 1
                text_file.close()

            #once time2 has been reached, set to phase 1 again
            if ((elapsed_time-last_chemoset > time2[x]) & (last_chemophase == 2)): 
                print('Switching back to phase 1 in vial ',x)

                #calculate the period (i.e. frequency of dilution events) based on user specified growth rate and bolus size
                if rate_config1[x] > 0:
                    period_config[x] = (3600*bolus)/((rate_config1[x])*volume)
                    period_config[x] = (period_config[x])*flow_rate[x]*(25/volume) #corrects for flow rates other than 1mL/sec and volumes other than 25mL

                else: #if no dilutions needed, then just loops with no dilutions
                    period_config[x] = 0

                #writes command to chemo_config file, for storage
                text_file = open(chemoconfig_path,"a+")
                text_file.write("%f,1,%i\n" %  (elapsed_time,period_config[x])) #note that this sets chemophase to 1
                text_file.close()
    #update chemostat command after all vials are dealt with            
    #MESSAGE = "c,%i,%i,%i,%i,%i,%i,%i,%i,%i,%i,%i,%i,%i,%i,%i,%i,%i," % (period_config[0],period_config[1],period_config[2],period_config[3],period_config[4],period_config[5],period_config[6],period_config[7],period_config[8],period_config[9],period_config[10],period_config[11],period_config[12],period_config[13],period_config[14],period_config[15],bolus)
    eVOLVER_module.update_chemo(vials,exp_name,bolus) #this uses values stored in chemo_config files



        
